### Steps to run the app

1. Download and unzip the file.
2. Run the command "npm install --save"
3. Then run the command "npm start" (this will start the GraphQL server).
5. Open new terminal window.
4. Navigate inside the client folder and run the command "npm install --save".
5. Then run the command "npm start" to start the client.
6. This will open the app in browser window and then you can add the quotes, update it and delete it as well.