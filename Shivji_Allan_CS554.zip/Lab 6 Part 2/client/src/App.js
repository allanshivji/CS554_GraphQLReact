import React, { Component } from 'react';
import { BrowserRouter as Router, Route } from 'react-router-dom';
import './App.css';
import Quotes from './components/QuoteData';

class App extends Component {
  render() {
    return (
      <Router>
        <div>
          <header className="App-Header-Center">
            <h1>
              This is GraphQL With Apollo Client and Server
              <br />
              Chuck Noris Quotes
          </h1>
          </header>
          <Route path="/" component={Quotes}/>
        </div>
      </Router>
    );
  }
}


export default App;
