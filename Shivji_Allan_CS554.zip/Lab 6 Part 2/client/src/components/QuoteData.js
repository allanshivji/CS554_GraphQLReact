import React, { Component } from 'react';
import { Query } from 'react-apollo';

import AddQuote from '../components/modals/AddQuote';
import DeleteQuoteModal from '../components/modals/DeleteQuoteModal';
import EditQuoteModal from '../components/modals/EditQuoteModal';

import queries from '../queries';

class Quotes extends Component {

    constructor(props) {
        super(props);
        this.state = {
            showEditModal: false,
            showAddModal: false,
            editQuote: null
        };
        this.handleOpenEditQuote = this.handleOpenEditQuote.bind(this);
        this.handleOpenAddQuote = this.handleOpenAddQuote.bind(this);
        this.handleCloseQuote = this.handleCloseQuote.bind(this);
    }

    handleOpenEditQuote(quotes) {
        this.setState({
            showEditModal: true,
            editQuote: quotes
        });
    }

    handleOpenDeleteModal(quotes) {
        this.setState({
            showDeleteModal: true,
            deleteQuote: quotes
        })
    }

    handleCloseQuote() {
        this.setState({
            showAddModal: false,
            showEditModal: false,
            showDeleteModal: false
        });
    }

    handleOpenAddQuote() {
        this.setState({ showAddModal: true });
    }

    render() {

        return (
            <div>
                <div className="App-Header-Center">
                    <button className="btn btn-primary" onClick={this.handleOpenAddQuote}>
                        Create Quote +
                </button>
                </div>
                <br />
                <Query query={queries.GET_QUOTES}>
                    {({ data }) => {
                        const quote = data.quotes;
                        if (!quote) {
                            return null;
                        }
                        return (
                            <div>
                                {quote.map(quotes => {
                                    return (
                                        <div className="card" key={quotes.id}>
                                            <div className="card-body">
                                                <p> {quotes.quote} </p>
                                            </div>
                                            <button className="btn btn-success"
                                                onClick={() => {
                                                    this.handleOpenEditQuote(quotes)
                                                }}
                                            >
                                                Update
                                                </button>
                                            <button
                                                className="btn btn-danger"
                                                onClick={() => {
                                                    this.handleOpenDeleteModal(quotes);
                                                }}
                                            >
                                                Delete
                                                </button>
                                        </div>
                                    )
                                })}
                            </div>
                        )
                    }}


                </Query>
                {/* Edit Quote */}
                {this.state && this.state.showEditModal && (
                    <EditQuoteModal
                        isOpen={this.state.showEditModal}
                        quote={this.state.editQuote}
                        handleClose={this.handleCloseQuote}
                    />
                )}

                {/* Add Quote */}
                {this.state && this.state.showAddModal && (
                    <AddQuote
                        isOpen={this.state.showAddModal}
                        handleClose={this.handleCloseQuote}
                        modal="addQuote"
                    />
                )}

                {/* Delete Quote */}
                {this.state && this.state.showDeleteModal && (
                    <DeleteQuoteModal
                    isOpen={this.state.showDeleteModal}
                    handleClose={this.handleCloseQuote}
                    deleteQuote={this.state.deleteQuote}
                />
                )}
            </div>
        )


    }


}

export default Quotes