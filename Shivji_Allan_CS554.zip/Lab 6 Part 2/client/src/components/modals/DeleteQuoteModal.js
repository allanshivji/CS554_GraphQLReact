import React, { Component } from 'react';

import { Mutation } from 'react-apollo';
import ReactModal from 'react-modal';

import queries from '../../queries';

ReactModal.setAppElement("#root");
const customStyles = {
    content: {
        top: "50%",
        left: "50%",
        right: "auto",
        bottom: "auto",
        marginRight: "-50%",
        transform: "translate(-50%, -50%)",
        width: "50%",
        border: "1px solid #28547a",
        borderRadius: "4px"
    }
};

class DeleteQuoteModal extends Component {

    constructor(props) {
        super(props)
        this.state = {
            showDeleteModal: this.props.isOpen,
            quotes: this.props.deleteQuote
        };
        this.handleOpenDeleteModal = this.handleOpenDeleteModal.bind(this);
        this.handleCloseDeleteModal = this.handleCloseDeleteModal.bind(this);
    }

    handleOpenDeleteModal() {
        this.setState({ showDeleteModal: true });
    }

    handleCloseDeleteModal() {
        this.setState({ showDeleteModal: false });
        this.props.handleClose(false);
    }

    render() {

        return (
            <ReactModal
                name="deleteModal"
                isOpen={this.state.showDeleteModal}
                contentLabel="Delete Quote"
                style={customStyles}
            >
                <Mutation
                    mutation={queries.DELETE_QUOTE}
                    update={(cache, { data: { removeQuote } }) => {
                        const { quotes } = cache.readQuery({
                            query: queries.GET_QUOTES
                        });
                        cache.writeQuery({
                            query: queries.GET_QUOTES,
                            data: {
                                quotes: quotes.filter(
                                    e => e.id !== this.state.quotes.id
                                )
                            }
                        });
                    }}
                >
                    {(removeQuote, { data }) => (
                        <div>
                            <p> Are you sure you want to delete Quote? </p>
                            <form
                                className="form"
                                id="delete-quote"
                                onSubmit={e => {
                                    e.preventDefault();
                                    removeQuote({
                                        variables: {
                                            id: this.state.quotes.id
                                        }
                                    });
                                    this.setState({ showDeleteModal: false });
                                    this.props.handleClose();
                                }}
                            >
                                <br />
                                <button className="btn btn-danger" type="submit">
                                    Yes
                                </button>
                            </form>
                        </div>
                    )}
                </Mutation>
                <br />
                <button
                    className="btn btn-primary"
                    onClick={this.handleCloseDeleteModal}
                >
                    No
                </button>
            </ReactModal>
        )

    }


}

export default DeleteQuoteModal;