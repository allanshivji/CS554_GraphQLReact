import React, { Component } from 'react';
import { Mutation } from 'react-apollo';
import ReactModal from 'react-modal';

import queries from '../../queries';

ReactModal.setAppElement("#root");
const customStyles = {
    content: {
        top: "50%",
        left: "50%",
        right: "auto",
        bottom: "auto",
        marginRight: "-50%",
        transform: "translate(-50%, -50%)",
        width: "50%",
        border: "1px solid #28547a",
        borderRadius: "4px"
    }
};

class EditQuoteModal extends Component {

    constructor(props) {
        super(props);
        this.state = {
            showEditModal: this.props.isOpen,
            quote: this.props.quote
        };
        this.handleCloseEditModal = this.handleCloseEditModal.bind(this);
    }

    handleCloseEditModal() {
        this.setState({ showEditModal: false, quote: null });
        this.props.handleClose();
    }

    render() {

        let quote;
        return (
            <div>
                <ReactModal
                    name="editModal"
                    isOpen={this.state.showEditModal}
                    contentLabel="Edit Quote"
                    style={customStyles}
                >

                    <Mutation mutation={queries.EDIT_QUOTE}>
                        {(editQuote, { data }) => (
                            <form
                                className="form"
                                id="edit-quote"
                                onSubmit={e => {
                                    e.preventDefault();
                                    console.log("Allan "+quote.value);
                                    editQuote({
                                        variables: {
                                            id: this.props.quote.id,
                                            quote: quote.value
                                        }
                                    });
                                    quote.value = "";
                                    this.setState({ showEditModal: false });
                                    this.props.handleClose();
                                }}
                            >
                                <div className="form-group">
                                    <label>
                                        Quote: <input
                                            ref={node => {
                                                quote = node;
                                            }}
                                            defaultValue={this.props.quote.quote}
                                            autoFocus={true}
                                        />
                                    </label>
                                </div>
                                <br />
                                <button className="btn btn-success" type="submit">
                                    Update Quote
                                </button>
                                <button
                                    className="btn btn-danger"
                                    onClick={this.handleCloseEditModal}
                                >
                                    Cancel
                                </button>
                            </form>
                        )}
                    </Mutation>

                </ReactModal>
            </div>
        );

    }
}

export default EditQuoteModal;