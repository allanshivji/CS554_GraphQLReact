import gql from 'graphql-tag';


const GET_QUOTES = gql`
    query {
        quotes {
            id
            quote
        }
    }
`;

const ADD_QUOTE = gql`
    mutation (
        $quote: String!
    ) {
        addQuote(quote: $quote) {
            id
            quote
        }
    }
`;

const DELETE_QUOTE = gql`
    mutation deleteQuote($id: String!){
        removeQuote(id: $id){
            id
            quote
        }
    }
`;

const EDIT_QUOTE = gql`
    mutation editQuote(
        $id: String!
        $quote: String!
    ) {
        editQuote(
            id: $id
            quote: $quote
        ) {
            id
            quote
        }
    }
`;

export default {
    GET_QUOTES,
    ADD_QUOTE,
    DELETE_QUOTE,
    EDIT_QUOTE
}