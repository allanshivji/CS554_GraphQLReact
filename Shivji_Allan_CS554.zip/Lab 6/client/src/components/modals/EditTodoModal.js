import React, { Component } from 'react';
import { Mutation } from 'react-apollo';
import ReactModal from 'react-modal';

import queries from '../../queries';

ReactModal.setAppElement("#root");
const customStyles = {
    content: {
        top: "50%",
        left: "50%",
        right: "auto",
        bottom: "auto",
        marginRight: "-50%",
        transform: "translate(-50%, -50%)",
        width: "50%",
        border: "1px solid #28547a",
        borderRadius: "4px"
    }
};

class EditTodoModal extends Component {

    constructor(props) {
        super(props);
        this.state = {
            showEditModal: this.props.isOpen,
            todo: this.props.todo,
            flagValue: false
        };
        this.handleCloseEditModal = this.handleCloseEditModal.bind(this);
    }

    handleCloseEditModal() {
        this.setState({ showEditModal: false, todo: null });
        this.props.handleClose();
    }

    handleChange(e) {
        if(e.target.value === "1"){
            this.setState({flagValue: false});
        }
        if(e.target.value === "2"){
            this.setState({flagValue: true});
        } else{
            this.setState({flagValue: false});
        }
        
    }

    render() {
        let todoDescription;

        return (
            <div>
                <ReactModal
                    name="editModal"
                    isOpen={this.state.showEditModal}
                    contentLabel="Edit Todo"
                    style={customStyles}
                >

                    <Mutation mutation={queries.EDIT_TODO}>
                        {(editTodo, { data }) => (
                            <form
                                className="form"
                                id="edit-todo"
                                onSubmit={e => {
                                    e.preventDefault()
                                    editTodo({
                                        variables: {
                                            id: this.props.todo.id,
                                            todoDescription: todoDescription.value,
                                            flag: this.state.flagValue
                                        }
                                    });
                                    todoDescription.value = ""
                                    this.setState({ showEditModal: false });
                                    this.props.handleClose();
                                }}
                            >
                                <div className="form-group">
                                    <label>
                                        Description: <input
                                            ref={node => {
                                                todoDescription = node;
                                            }}
                                            defaultValue={this.props.todo.todoDescription}
                                            autoFocus={true}
                                        />
                                    </label>
                                </div>
                                <br />
                                <div>
                                <label>
                                    Completed:
                                    <select onChange={this.handleChange.bind(this)}>
                                        <option value="1">False</option>
                                        <option value="2">True</option>
                                    </select>
                                </label>
                                </div>
                                <br />
                                <br />
                                <button className="btn btn-success" type="submit">
                                    Update Todo
                                </button>
                                <button
                        className="btn btn-danger"
                        onClick={this.handleCloseEditModal}
                    >
                        Cancel
          </button>
                            </form>
                        )}
                    </Mutation>
                    
                </ReactModal>
            </div>
        );
    }


}

export default EditTodoModal;