import React, { Component } from 'react';

import { Mutation } from 'react-apollo';
import ReactModal from 'react-modal';

import queries from '../../queries';

ReactModal.setAppElement("#root");
const customStyles = {
    content: {
        top: "50%",
        left: "50%",
        right: "auto",
        bottom: "auto",
        marginRight: "-50%",
        transform: "translate(-50%, -50%)",
        width: "50%",
        border: "1px solid #28547a",
        borderRadius: "4px"
    }
};

class DeleteTodoModal extends Component {
    constructor(props) {
        super(props);
        this.state = {
            showDeleteModal: this.props.isOpen,
            todos: this.props.deleteTodo
        };

        this.handleOpenDeleteModal = this.handleOpenDeleteModal.bind(this);
        this.handleCloseDeleteModal = this.handleCloseDeleteModal.bind(this);
    }

    handleOpenDeleteModal() {
        this.setState({ showDeleteModal: true });
    }

    handleCloseDeleteModal() {
        this.setState({ showDeleteModal: false });
        this.props.handleClose(false);
    }

    render() {
        return (
            <ReactModal
                name="deleteModal"
                isOpen={this.state.showDeleteModal}
                contentLabel="Delete Todo"
                style={customStyles}
            >
                <Mutation
                    mutation={queries.DELETE_TODO}
                    update={(cache, { data: { removeTodo } }) =>{
                        const {todos} = cache.readQuery({
                            query: queries.GET_TODOS
                        });
                        cache.writeQuery({
                            query: queries.GET_TODOS,
                            data: {
                                todos: todos.filter(
                                    e => e.id !== this.state.todos.id
                                )
                            }
                        });
                    }}
                >

                {(removeTodo, {data}) => (
                    <div>
                        <p> Are you sure you want to delete Todo?
                        </p>
                        <form
                            className="form"
                            id="delete-todo"
                            onSubmit={e => {
                                e.preventDefault();
                                removeTodo({
                                    variables: {
                                        id: this.state.todos.id
                                    }
                                });
                                this.setState({showDeleteModal: false});
                                this.props.handleClose();
                            }}
                        >
                        <br />
                        <br />
                        <button className="btn btn-danger" type="submit">
                            Yes
                        </button>

                        </form>

                    </div>
                )}
                </Mutation>
                <br />
                <br />
                <button
                className="btn btn-primary"
                onClick={this.handleCloseDeleteModal}
                >
                No
                </button>


            </ReactModal>
        );
    }
}

export default DeleteTodoModal;