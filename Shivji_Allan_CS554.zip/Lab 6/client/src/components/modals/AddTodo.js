import React, { Component } from 'react';
import { Query, Mutation } from 'react-apollo';
import ReactModal from 'react-modal';

import queries from '../../queries';

ReactModal.setAppElement("#root");
const customStyles = {
    content: {
        top: "50%",
        left: "50%",
        right: "auto",
        bottom: "auto",
        marginRight: "-50%",
        transform: "translate(-50%, -50%)",
        width: "50%",
        border: "1px solid #28547a",
        borderRadius: "4px"
    }
};

class AddTodo extends Component {

    constructor(props) {
        super(props);
        this.state = {
            showAddModal: this.props.isOpen
        };
        this.handleOpenAddModal = this.handleOpenAddModal.bind(this);
        this.handleCloseAddModal = this.handleCloseAddModal.bind(this);
    }

    handleOpenAddModal() {
        this.setState({ showAddModal: true });
    }

    handleCloseAddModal() {
        this.setState({ showAddModal: false });
        this.props.handleClose(false);
    }

    render() {
        let body;
        let userId;

        if (this.props.modal === "addTodo") {
            let todoDescription;

            body = (
                <Mutation
                    mutation={queries.ADD_TODO}
                    update={(cache, { data: { addTodo } }) => {
                        const { todos } = cache.readQuery({
                            query: queries.GET_TODOS
                        });

                        cache.writeQuery({
                            query: queries.GET_TODOS,
                            data: { todos: todos.concat([addTodo]) }
                        });
                    }}
                >
                    {(addTodo, { data }) => (
                        
                        <form
                            className="form"
                            id="add-todo"
                            onSubmit={e => {
                                addTodo({
                                    variables: {
                                        todoDescription: todoDescription.value,
                                        userId: parseInt(userId.value)
                                    }
                                });
                                todoDescription.value = "";
                                userId.value = "1";
                                this.setState({ showAddModal: false })
                                // alert("Todo Added Succesfully!!!");
                                this.props.handleClose();
                            }}
                        >
                            <div className="form-group">
                                <label>
                                    Enter your Todo:
                    <br />
                                    <input
                                        ref={node => {
                                            todoDescription = node
                                        }}
                                        required
                                        autoFocus={true}
                                    />
                                </label>
                            </div>
                            <br />

                            <Query query={queries.GET_USERS}>
                            
                                {({ data }) => {
                                    const { users } = data;
                                    console.log(users);
                                    if (!users) {
                                        return null;
                                    }
                                    return (
                                        
                                        <div className="form-group">
                                            <label>
                                                User:
                                                <select
                                                    className="form-control"
                                                    ref={node => {
                                                        userId = node;
                                                    }}
                                                >
                                                    {users.map(user => {
                                                        return (
                                                            <option key={user.id} value={user.id}>
                                                                {user.name}
                                                            </option>
                                                        );
                                                    })}
                                                </select>
                                            </label>
                                        </div>
                                    );
                                }}
                            </Query>


                            <br />
                            <br />
                            <button className="btn btn-primary" type="submit">
                                Add Todo
                    </button>
                        </form>
                    )}
                </Mutation>
            );
        }

        return (
            <div>
                <ReactModal
                    name="addTodo"
                    isOpen={this.state.showAddModal}
                    contentLabel="Add Todo"
                    style={customStyles}
                >
                    {body}
                    <button
                        className="btn btn-danger"
                        onClick={this.handleCloseAddModal}
                    >
                        Cancel
                </button>
                </ReactModal>
            </div>
        );
    }
}

export default AddTodo;