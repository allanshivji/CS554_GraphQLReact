import React, { Component } from 'react';
import { Query } from 'react-apollo';

import AddTodo from '../components/modals/AddTodo';
import DeleteTodoModal from '../components/modals/DeleteTodoModal';
import EditTodoModal from '../components/modals/EditTodoModal';

import queries from '../queries';

class Todos extends Component {

    constructor(props) {
        super(props);
        this.state = {
            showEditModal: false,
            showAddModal: false,
            editTodo: null
        };
        this.handleOpenEditTodo = this.handleOpenEditTodo.bind(this);
        this.handleOpenAddTodo = this.handleOpenAddTodo.bind(this);
        this.handleCloseTodo = this.handleCloseTodo.bind(this);
    }

    handleOpenEditTodo(todos) {
        this.setState({
            showEditModal: true,
            editTodo: todos
        });
    }

    handleOpenDeleteModal(todos) {
        this.setState({
            showDeleteModal: true,
            deleteTodo: todos
        })
    }

    handleCloseTodo() {
        this.setState({
            showAddModal: false,
            showEditModal: false,
            showDeleteModal: false
        });
    }

    handleOpenAddTodo() {
        this.setState({ showAddModal: true });
    }

    render() {
        return (
            <div>
                <div className="App-Header-Center">
                <button className="btn btn-primary" onClick={this.handleOpenAddTodo}>
                    Create Todo +
                </button>
                </div>
                <br />
                <Query query={queries.GET_TODOS}>
                    {({ data }) => {
                        const todo = data.todos;
                        if (!todo) {
                            return null;
                        }
                        return (
                            <div>
                                {todo.map(todos => {
                                    var fl;
                                    if(todos.flag === false){
                                        fl = "No";
                                    }
                                    if(todos.flag === true) {
                                        fl = "Yes";
                                    }
                                    return (
                                        <div className="card" key={todos.id}>
                                            <div className="card-body">
                                                <h2>{todos.user.name}</h2>

                                                <p>
                                                    Task: {todos.todoDescription}
                                                </p>
                                                <p>Completed: {fl}
                                                </p>
                                                <br />
                                                <button className="btn btn-success"
                                                    onClick={() => {
                                                        this.handleOpenEditTodo(todos)
                                                    }}
                                                >
                                                    Update
                                                </button>
                                                <button
                                                    className="btn btn-danger"
                                                    onClick={() => {
                                                        this.handleOpenDeleteModal(todos);
                                                    }}
                                                >
                                                    Delete
                                                </button>
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        );
                    }}
                </Query>
                {/* Edit Todo */}
                {this.state && this.state.showEditModal && (
                    <EditTodoModal
                        isOpen={this.state.showEditModal}
                        todo={this.state.editTodo}
                        handleClose={this.handleCloseTodo}
                    />
                )}

                {/* Add Todo */}
                {this.state && this.state.showAddModal && (
                    <AddTodo
                        isOpen={this.state.showAddModal}
                        handleClose={this.handleCloseTodo}
                        modal="addTodo"
                    />
                )}
                {/* Delete Todo */}
                {this.state && this.state.showDeleteModal && (
                    <DeleteTodoModal
                        isOpen={this.state.showDeleteModal}
                        handleClose={this.handleCloseTodo}
                        deleteTodo={this.state.deleteTodo}
                    />
                )}
            </div>
        );
    }

}

export default Todos;