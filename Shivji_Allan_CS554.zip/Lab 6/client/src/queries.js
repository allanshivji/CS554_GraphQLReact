import gql from 'graphql-tag';

const GET_TODOS = gql`
    query {
        todos {
            id
            todoDescription
            flag
            user {
                name
                id
            }
        }
    }
`;

const GET_USERS = gql`
    query {
        users {
            name
            id
        }
    }
`;

const ADD_TODO = gql`
    mutation (
        $todoDescription: String!
        $userId: Int!
    ) {
        addTodo(todoDescription: $todoDescription, userId: $userId)  {
            todoDescription
            user {
                id
                name
            }
        }     
    }
`;
 
const DELETE_TODO = gql`
    mutation deleteTodo($id: String!){
        removeTodo(id: $id){
            id
            todoDescription
        }
    }
`;

const EDIT_TODO = gql`
    mutation editTodo(
        $id: String!
        $todoDescription: String!
        $flag: Boolean!
    ) {
        editTodo(
            id: $id
            todoDescription: $todoDescription
            flag: $flag
        ) {
            id
            todoDescription
            flag
            user {
                id
                name
            }
        }
    }
`;

export default {
    GET_TODOS,
    GET_USERS,
    ADD_TODO,
    DELETE_TODO,
    EDIT_TODO
}